<table class="table table-condensed">
  <tr>
    <td>标题</td>
    <td>日期</td>
    <td>回帖数</td>    
    <td>已审核?</td>             
    <td>已发布?</td>
    <td>操作</td>
  </tr>
  <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <td><?php echo e($item->name); ?></td>
      <td><?php echo e($item->created_at->toDateString()); ?></td>
      <td><?php echo e($item->forumThreadReplies->count()); ?></td>      
      <td>
        <span class='<?php echo e($item->isChecked ? '' : 'label label-danger'); ?>'><?php echo e($item->isChecked ? '是' : '否'); ?></span>
      </td>
      <td>
        <span class='<?php echo e($item->isPublished ? '' : 'label label-danger'); ?>'><?php echo e($item->isPublished ? '是' : '否'); ?></span>
      </td>
      <td>
        <?php echo e(link_to_action('ForumThreadMainController@show', $title = '查看', $parameters = [$item->id], $attributes = ['class'=>"btn btn-primary btn-xs"])); ?>

        
        <?php echo e(Form::open(['method' => 'DELETE', 'route' => ['Forum.destroy',$item->id],'style'=>"display: inline-block;"])); ?>

          <?php echo e(Form::hidden('id', $item->id)); ?>

          <?php echo e(Form::submit('删除', ['class' => 'btn btn-danger btn-xs'])); ?>

        <?php echo e(Form::close()); ?>


        <?php if(!$item->isChecked): ?>
        <?php echo e(link_to_action('ForumThreadMainController@checkMain', $title = '审核通过', $parameters = [$item->id], $attributes = ['class'=>"btn btn-warning btn-xs", 'target'=>'_blank'])); ?>

        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr><td colspan=6>无数据</td></tr>
  <?php endif; ?>

</table>
