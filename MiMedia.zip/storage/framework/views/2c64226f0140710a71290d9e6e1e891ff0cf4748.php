

<?php $__env->startSection('content'); ?>
<h2>创建电台节目</h2>
<?php echo e(Form::open(['action' => 'RadioProgrameController@store', 'files' => true, 'autocomplete' => 'off',])); ?>

  <div class="form-horizontal">
    <hr />

    <div class="form-group<?php echo e($errors->has('radioChannelId') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('radioChannelId', '* 频道', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::select('radioChannelId', ['1' => '早安密西根', '2' => '密西根生活', '3' => '音乐台', '4' => '汽车人'], null, ['placeholder' => '选择频道...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('name', '* 标题', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::text('name', null, ['placeholder' => '输入标题...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>    

    <div class="form-group<?php echo e($errors->has('shortContent') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('shortContent', '* 简介', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::text('shortContent', null, ['placeholder' => '输入简介...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>    

    <div class="form-group<?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('content', '* 文本内容', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::textarea('content', null, ['placeholder' => '输入文本内容...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('date') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('date', '* 显示日期', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::text('date', (new \Carbon\Carbon())->toDateString(), ['placeholder' => '输入显示日期 (格式为2017-01-31)...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('image', '* 封面图片', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::file('image', null, ['placeholder' => '选择封面图片...', 'class' => 'form-control','required' =>"true", 'id'=>'image'])); ?>

      </div>
    </div>


    <div class="form-group<?php echo e($errors->has('radio') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('radio', '* 音频(mp3)', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::file('radio', null, ['placeholder' => '选择节目音频...', 'class' => 'form-control','required' =>"true", 'id'=>'radio'])); ?>

      </div>
    </div>

    <div class="form-group">
      <div class="col-md-offset-2 col-md-10">
        <input type="submit" id="submit" value="创建" class="btn btn-primary" />
      </div>
    </div>
  </div>

<?php echo e(Form::close()); ?>


<?php $__env->startSection('jq_scripts'); ?>
  <script type="text/javascript">
  $(document).ready(function() {
    $('#submit').bind("click",function(){
    //$("form").submit(function(e){
      e.preventDefault();                 
      var continueInvoke = true;

      var imgVal = $('#image').val(); 
      if(imgVal=='') 
      { 
          alert("需要封面图片"); 
          continueInvoke = false; 
      } 

      var radioVal = $('#radio').val(); 
      if(radioVal=='') 
      { 
          alert("需要节目视频"); 
          continueInvoke = false; 
      } 
      
      if(continueInvoke == true){
          $("form").submit();
      }
    });
  });
  </script> 
<?php $__env->stopSection(); ?>

<div>
  <?php echo e(link_to_action('RadioProgrameController@index', $title = '返回', $parameters = [], $attributes = ['class'=>"btn btn-link"])); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>