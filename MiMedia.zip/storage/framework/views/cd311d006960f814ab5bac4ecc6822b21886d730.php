

<?php $__env->startSection('content'); ?>
<h2>修改用户类型 ( <?php echo e($item->email); ?> / <?php echo e($item->name); ?> )</h2>
<?php echo e(Form::open(['route' => ['User.modifyType', $item->id],'method' => 'put'])); ?>

  <div class="form-horizontal">
    <hr />
    <?php echo e(Form::hidden('id', $item->id)); ?>


    <div class="form-group">
      <?php echo e(Form::label('isADClient', '广告客户?', ['class' => 'col-md-2 control-label text-danger'])); ?>


      <div class="col-md-4">
        <?php echo e(Form::checkbox('isADClient', 1, $item->isADClient,['style' => 'margin-top: 14px;'])); ?>

      </div>
    </div>

    <hr />

    <div class="form-group">
      <?php echo e(Form::label('isSystemManager', '管理员?', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-1">
        <?php echo e(Form::checkbox('isSystemManager', 1, $item->isSystemManager,['style' => 'margin-top: 14px;'])); ?>

      </div>

      <?php echo e(Form::label('isEditor', '编辑?', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-1">
        <?php echo e(Form::checkbox('isEditor', 1, $item->isEditor,['style' => 'margin-top: 14px;'])); ?>

      </div>  

      <?php echo e(Form::label('isAuditor', '审核?', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-1">
        <?php echo e(Form::checkbox('isAuditor', 1, $item->isAuditor,['style' => 'margin-top: 14px;'])); ?>

      </div>

      <?php echo e(Form::label('isADManager', '广告管理?', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-1">
        <?php echo e(Form::checkbox('isADManager', 1, $item->isADManager,['style' => 'margin-top: 14px;'])); ?>

      </div>          
    </div>

    <div class="form-group">
      <div class="col-md-offset-1 col-md-11">
        <input type="submit" value="保存" class="btn btn-primary" />
      </div>
    </div>
  </div>

<?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>