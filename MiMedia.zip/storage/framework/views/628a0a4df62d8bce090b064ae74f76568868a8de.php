
<?php $__env->startSection('content'); ?>
 标题: <?php echo e($main['name']); ?>

<table class="table table-condensed">
  <tr>
    <td>内容</td>
    <td style='width: 90px;'>日期</td>
    <td style='width: 100px;'>发帖人</td>
    <td>操作</td>
  </tr>
  <tr>
    <td>
    
      <?php echo strlen($main['content'])>0? $main['content'] : '【无内容】'; ?>

    
    </td>
    <td><?php echo e($main['date']); ?></td>
    <td><?php echo e($main['authorName']); ?></td>
    <td>
     
      <?php echo e(Form::open(['method' => 'DELETE', 'route' => ['Forum.destroy',$main['id']],'style'=>"display: inline-block;"])); ?>

        <?php echo e(Form::hidden('id', $main['id'])); ?>

        <?php echo e(Form::submit('删除主贴', ['class' => 'btn btn-danger btn-xs'])); ?>

      <?php echo e(Form::close()); ?>

    </td>
  </tr>  
  <?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td>
      <?php $__currentLoopData = explode("\n",$item['content']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p> >> <?php echo e($content); ?></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </td>    
      <td><?php echo e($item['date']); ?></td>
      <td><?php echo e($item['authorName']); ?></td>
      <td>
       
        <?php echo e(Form::open(['method' => 'DELETE', 
        'route' => ['Forum.destroyReply','threadReplyid' => $item['id']],'style'=>"display: inline-block;"])); ?>

          <?php echo e(Form::hidden('id', $item['id'])); ?>

          <?php echo e(Form::submit('删除回复', ['class' => 'btn btn-danger btn-xs'])); ?>

        <?php echo e(Form::close()); ?>

      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e(link_to_action('ForumThreadMainController@index', $title = '返回: '. $board->caption, 
  $parameters = ['id'=> $board->id])); ?><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>