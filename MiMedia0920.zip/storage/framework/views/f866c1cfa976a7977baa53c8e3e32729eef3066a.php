

<?php $__env->startSection('content'); ?>
<h2>修改广告图片 - <?php echo e($data->caption); ?></h2>
<?php echo e(Form::open(['action' => ['AdSettingController@update', $data['id']], 
'files' => true, 'method'=>'PUT', 'autocomplete' => 'off',])); ?>

  <div class="form-horizontal">
    <hr />

    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('name', '* 位置', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::select('name', ['tv-programe-list' => '电视', 'radio-station-list' => '电台', 'forum-board-list' => '论坛'], $data->name, ['placeholder' => '选择位置...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('customerId') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('customerId', '* 广告客户账户', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::select('customerId', $adCustomers, $data->customerId, ['placeholder' => '选择广告客户账户...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('image', '广告图片', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <strong>原广告图片(如需保留该图片则不需要再次上传):</strong>
        <img src='<?php echo e($resourceUrlPrefix . $data->imageUrl); ?>' style='max-width: 300px; border: rgb(128, 128, 128) dotted;'>
        <?php echo e(Form::file('image', null, ['class' => 'form-control','id'=>'image'])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('displayOrder') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('displayOrder', '* 显示序号', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::text('displayOrder', $data->displayOrder, ['placeholder' => '输入显示序号,必须为整数数字...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('startFrom') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('startFrom', '* 开始日期', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::text('startFrom',  $data->startFrom->toDateString(), ['placeholder' => '输入开始日期 (格式为2017-01-31)...', 'class' => 'form-control','required' =>"true"])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('endTo') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('endTo', '结束日期', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::text('endTo', ($data->endTo ? $data->endTo->toDateString() : ''), ['placeholder' => '输入结束日期 (格式为2017-11-31)...', 'class' => 'form-control'])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('caption') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('caption', '标题', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::text('caption', $data->caption, ['placeholder' => '输入标题...', 'class' => 'form-control'])); ?>

      </div>
    </div>    

    <div class="form-group<?php echo e($errors->has('contentUrl') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('contentUrl', '内容页链接', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::text('contentUrl', $data->contentUrl, ['placeholder' => '输入内容页链接...', 'class' => 'form-control'])); ?>

      </div>
    </div>

    <div class="form-group<?php echo e($errors->has('memo') ? ' has-error' : ''); ?>">
      <?php echo e(Form::label('memo', '备注', ['class' => 'col-md-2 control-label'])); ?>


      <div class="col-md-10">
        <?php echo e(Form::textarea('memo', $data->memo, ['placeholder' => '输入备注...', 'class' => 'form-control'])); ?>

      </div>
    </div>

    <div class="form-group">
      <div class="col-md-offset-2 col-md-10">
        <input type="submit" id="submit" value="提交" class="btn btn-primary" />
      </div>
    </div>
  </div>

<?php echo e(Form::close()); ?>


<div>
  <?php echo e(link_to_action('AdSettingController@index', $title = '返回', $parameters = [], $attributes = ['class'=>"btn btn-link"])); ?>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>