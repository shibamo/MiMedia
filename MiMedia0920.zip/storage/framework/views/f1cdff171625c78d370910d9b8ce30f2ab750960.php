
<?php $__env->startSection('content'); ?>
<?php echo e(link_to_route('AdSetting.create', $title = '新建广告', $parameters = [], $attributes = ['class'=>"btn btn-primary btn-lg", 'style'=>"margin-top: 5px; margin-bottom: 5px;"])); ?>

<table class="table table-condensed">
  <tr>
    <td>位置</td>
    
    <td>序号</td>
    <td>图片</td>
    <td>内容页地址</td>
    <td>起止日期</td>
    <td>客户号</td>
    
    <td>备注</td>
    <td style='width: 100px;'>操作</td>
  </tr>
  <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr>
      <td><?php echo e($item->name); ?></td>
      
      <td><span class="badge progress-bar-danger"><?php echo e($item->displayOrder); ?></span></td>
      <td><img src='<?php echo e($resourceUrlPrefix . $item->imageUrl); ?>' style='max-width: 300px; border: rgb(128, 128, 128) dotted;'> </td>
      <td><?php echo e($item->contentUrl); ?></td>
      <td>
        <?php echo e($item->startFrom->toDateString()); ?> : 
        <strong class="<?php echo e($item->endTo && $item->endTo->lte(new \Carbon\Carbon()) ? 'text-danger' : 'text-success'); ?> "><?php echo e($item->endTo ? $item->endTo->toDateString() : ''); ?></strong>
      </td>
      
      <td><?php echo e($item->customerId); ?></td>
      <td><?php echo e($item->memo); ?></td>      
      <td>
        <?php echo e(link_to_action('AdSettingController@edit', $title = '修改', $parameters = [$item->id], $attributes = ['class'=>"btn btn-primary btn-xs"])); ?> | 
        <form action="<?php echo e(route('AdSetting.destroy', ['id' => $item->id])); ?>" method="POST" style='display: inline;'>
            <input type="hidden" name="_method" value="DELETE">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <button type=submit class="btn btn-danger btn-xs">删除</button>
        </form>
      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <tr><td colspan=3>无数据</td></tr>
  <?php endif; ?>

</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>