

<?php $__env->startSection('content'); ?>
  <h4>广告管理类用户列表</h4> 
<table class="table table-condensed table-striped table-bordered">
  <tr>
    <th class="primary">编号</th>
    <th class="primary">用户名</th>
    <th class="primary">邮箱</th>
    <th class="primary">管理员?</th>
    <th class="primary">编辑?</th>
    <th class="primary">审核?</th>
    <th class="primary">广告管理?</th>    
    <th class="primary">创建时间</th>
    <th class="primary">操作</th>
  </tr>

  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td>
        <?php echo e($item->id); ?>

      </td>
      <td>
        <?php echo e($item->name); ?>

      </td>
      <td>
        <?php echo e($item->email); ?>

      </td>
      <td>
        <?php echo e($item->isSystemManager ? 'X' : ''); ?>

      </td>
      <td>
        <?php echo e($item->isEditor ? 'X' : ''); ?>

      </td>
      <td>
        <?php echo e($item->isAuditor ? 'X' : ''); ?>

      </td>
      <td>
        <?php echo e($item->isADManager ? 'X' : ''); ?>

      </td>            
      <td>
        <?php echo e($item->created_at->toDateString()); ?>

      </td>
      <td>
        <?php echo e(link_to_route('User.adjustType', $title = '调整类型', 
        $parameters = ['id'=> $item->id])); ?>

      </td>
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>