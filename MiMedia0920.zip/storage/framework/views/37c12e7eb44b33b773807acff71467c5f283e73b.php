
<?php $__env->startSection('content'); ?>
  <h4>论坛列表</h4> 
  <div>
    <!-- Nav tabs -->
    <ul class="nav nav-tabs" role="tablist">
      <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li role="presentation" class="<?php echo e($board->id == $activeBoardId ? 'active' : ''); ?>">
          <a href="#<?php echo e($board->name); ?>" aria-controls="<?php echo e($board->name); ?>" role="tab" data-toggle="tab">
            <?php echo e($board->caption); ?>

          </a>
        </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <!-- Tab panes -->
    <div class="tab-content">
      <?php $__currentLoopData = $boards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $board): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div role="tabpanel" class="tab-pane <?php echo e($board->id == $activeBoardId ? 'active' : ''); ?>" id="<?php echo e($board->name); ?>"> 
          <?php echo $__env->make('forum-thread-main._thread_list', ['data' => $board->forumThreadMains->sortByDesc('created_at')->take(200)], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </div>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>