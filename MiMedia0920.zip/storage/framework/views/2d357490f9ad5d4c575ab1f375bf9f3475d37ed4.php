<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>D Asian Media (D亚洲传媒)</title>
    <!-- Latest compiled and minified CSS -->
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  </head>
  <body style="overflow-y:scroll;">

  <div id="app">
    <div class="container">
      <div class="row" >
        <div class="navbar navbar-default navbar-fixed-top">
          <div class="container-fluid">
            
            <?php echo $__env->make("partials._Layout_Top_Nav_Bar_Partial", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
        </div>
      </div>
      
      <div class="row" style="margin-top: 50px;">
        <div class="body-content">
          <?php echo $__env->yieldContent('content'); ?>
          <hr />
          <footer>
            <p class="text-center">
              &copy; <?php echo e(Carbon\Carbon::now()->year); ?> - D*亚洲传媒 | 技术问题请联系: <span class='text-danger'>qinchao@hotmail.com</span>
            </p>
          </footer>
        </div>
      </div>
      
    </div>
  </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    <?php echo $__env->yieldContent("jq_scripts", ''); ?>
    
  </body>
</html>
