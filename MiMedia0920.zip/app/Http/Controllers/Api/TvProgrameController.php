<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\ApiController;

use App\TvChannel;
use App\TvPrograme;

class TvProgrameController extends ApiController
{
  public function index()
  {
    $grouped = TvPrograme::orderBy('date', 'desc')->get()->groupBy(function ($item, $key) {
      return  TvChannel::find($item['tvChannelId'])->name;
    });

    //return $grouped->toArray();
    return response()->json($grouped->toArray(), Response::HTTP_OK, $this->jsonHeader, JSON_UNESCAPED_UNICODE);
  }

  public function channels()
  {
    return response()->json(TvChannel::all(), Response::HTTP_OK, $this->jsonHeader, JSON_UNESCAPED_UNICODE);
  }
}