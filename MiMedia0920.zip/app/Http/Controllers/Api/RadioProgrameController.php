<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\ApiController;

use App\RadioChannel;
use App\RadioPrograme;

class RadioProgrameController extends ApiController
{
  public function index()
  {
    $grouped = RadioPrograme::orderBy('date', 'desc')->get()->groupBy(function ($item, $key) {
      return  RadioChannel::find($item['radioChannelId'])->name;
    });

    return response()->json($grouped->toArray(), Response::HTTP_OK, $this->jsonHeader, JSON_UNESCAPED_UNICODE);
  }

  public function channels()
  {
    return response()->json(RadioChannel::all(), Response::HTTP_OK, $this->jsonHeader, JSON_UNESCAPED_UNICODE);
  }
}