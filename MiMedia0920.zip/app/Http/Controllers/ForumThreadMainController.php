<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\ForumBoard;
use App\ForumThreadMain;
use App\ForumThreadReply;

class ForumThreadMainController extends Controller
{
  public function index(Request $request)
  {
    $boards = ForumBoard::all();

    return view('forum-thread-main.index',[
      'viewBag' => $this->viewBag,
      'boards' => $boards,
      'activeBoardId' => $request['id'] ?: 1,
      'currentFunction' => 'Forum',
    ]);
  }

  public function show($id)
  {
    $item = ForumThreadMain::find($id)->dto();
    return view('forum-thread-main.show',[
      'viewBag' => $this->viewBag,
      'main'=>$item,
      'board'=>ForumThreadMain::find($id)->forumBoard, 
      'currentFunction' => 'Forum',
      'replies' => $item['replies'],
    ]);
  }

  public function create()
  {
      //
  }

  public function store(Request $request)
  {
      //
  }
  public function edit($id)
  {
      //
  }


  public function update(Request $request, $id)
  {
      //
  }

  public function destroy($threadMainid)
  {
    ForumThreadMain::destroy($threadMainid);
    return redirect()->action('ForumThreadMainController@index');
    //return $threadMainid;
  }

  public function destroyReply($threadReplyid)
  {
    $threadMainid = ForumThreadReply::find($threadReplyid)->forumThreadId;
    ForumThreadReply::destroy($threadReplyid);
    return redirect()->action('ForumThreadMainController@show', 
      ['threadMainid'=>$threadMainid]);
    //return $threadMainid;
  }  
}
